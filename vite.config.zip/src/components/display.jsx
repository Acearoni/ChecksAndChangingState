import React, { useState } from 'react';

const Display = (props) => {
    const { toDo, setToDo } = props


    const toggleDoList = (task) => {
        const updatedDoList = toDo.map((taskFromMap) => {
            if (taskFromMap === task) {
                taskFromMap.hasCompleted = !task.hasCompleted
            }
            return taskFromMap
        })
        setToDo(updatedDoList)
    }

    const removeTask = (task) => {
        const updatedDoList = toDo.filter((taskFromFilter) => taskFromFilter !== task)
        setToDo(updatedDoList)
    }

    return (
        <div>
            <h2>Your Tasks</h2>
            {
                toDo.map((task, idx) => (
                    <div key={idx} style={{ border: '2px solid white', padding: 45 }}>
                        {
                            task.hasCompleted ?
                            <h3 style={{textDecoration: 'line-through'}}>Title: {task.title}</h3>:
                            <h3>Title: {task.title}</h3>
                        }
                        <input type="checkbox" onClick={() => toggleDoList(task)} defaultChecked={task.hasCompleted} />
                        <button onClick={() => removeTask(task)}>Delete</button>
                    </div>
                ))
            }
        </div>
    );
}

export default Display;
