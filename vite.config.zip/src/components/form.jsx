import React, { useState } from 'react';

const Form = (props) => {
    const {toDo, setToDo} = props
    const [title, setTitle] = useState('')


    //This is what happens after the form is submitted/refreshed.
    const submitHandler = (e) => {
        e.preventDefault()
        console.log('Submitted');
        const newTask = {
            title,
            hasCompleted:false
        }
        setToDo([...toDo, newTask])
        setTitle('')
    }


    return (
        <div>
            <h2>Add Task</h2>
            <form onSubmit={submitHandler}>
                <div>
                    <label>Title:</label>
                    <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
                </div>
                <button>Add Task</button>
            </form>
        </div>
    );
}

export default Form;
