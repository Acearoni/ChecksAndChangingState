import { useState } from 'react'
import './App.css'
import Display from './components/display'
import Form from './components/form'

function App() {
  const [toDo, setToDo] = useState([])
  return (
    <>
      <h2>Tasks To Complete</h2>
      <Form toDo = {toDo} setToDo = {setToDo} /> 
      <Display toDo = {toDo} setToDo = {setToDo}/>
    </>
  )
}

export default App
